import { Link } from "react-router";
import {
  Heart,
  Users,
  Home as HomeIcon,
  TrendingUp,
  ArrowRight,
} from "lucide-react";
import { mockProjects } from "../../data/mockData";

export function Home() {
  const stats = [
    { icon: Users, label: "Families Helped", value: "150+" },
    { icon: HomeIcon, label: "Homes Built", value: "45" },
    { icon: Heart, label: "Active Donors", value: "320+" },
    { icon: TrendingUp, label: "Success Rate", value: "98%" },
  ];

  const activeProjects = mockProjects.filter((p) => p.status === "active");

  return (
    <div>
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-red-600 to-red-800 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 md:py-28">
          <div className="max-w-3xl">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6">
              Building Hope, One Family at a Time
            </h1>
            <p className="text-xl md:text-2xl mb-8 text-red-100">
              Help us provide safe homes and better futures for homeless and
              poor families in our community.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Link
                to="/donate"
                className="px-8 py-4 bg-white text-red-600 rounded-lg font-semibold hover:bg-red-50 transition-colors text-center"
              >
                Donate Now
              </Link>
              <Link
                to="/projects"
                className="px-8 py-4 bg-red-700 text-white rounded-lg font-semibold hover:bg-red-800 transition-colors border-2 border-white text-center"
              >
                View Projects
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {stats.map((stat, index) => {
              const Icon = stat.icon;
              return (
                <div key={index} className="text-center">
                  <div className="inline-flex items-center justify-center w-16 h-16 bg-red-100 rounded-full mb-4">
                    <Icon className="w-8 h-8 text-red-600" />
                  </div>
                  <div className="text-3xl font-bold text-gray-900 mb-1">
                    {stat.value}
                  </div>
                  <div className="text-sm text-gray-600">{stat.label}</div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Mission Section */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">
              Our Mission
            </h2>
            <p className="text-lg text-gray-600 mb-8">
              We connect compassionate donors and volunteers with verified
              charity projects that support homeless and poor families. Our
              organization manages all beneficiary verification, support
              collection, project execution, and impact reporting to ensure
              transparency, safety, and accountability.
            </p>
            <Link
              to="/about"
              className="inline-flex items-center gap-2 text-red-600 font-semibold hover:text-red-700"
            >
              Learn More About Us
              <ArrowRight className="w-5 h-5" />
            </Link>
          </div>
        </div>
      </section>

      {/* Active Projects */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-end mb-8">
            <div>
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-2">
                Current Projects
              </h2>
              <p className="text-lg text-gray-600">
                Help families in need get back on their feet
              </p>
            </div>
            <Link
              to="/projects"
              className="hidden sm:inline-flex items-center gap-2 text-red-600 font-semibold hover:text-red-700"
            >
              View All Projects
              <ArrowRight className="w-5 h-5" />
            </Link>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {activeProjects.map((project) => {
              const progress =
                (project.currentAmount / project.targetAmount) * 100;
              return (
                <Link
                  key={project.id}
                  to={`/projects/${project.id}`}
                  className="bg-white border border-gray-200 rounded-xl overflow-hidden hover:shadow-lg transition-shadow"
                >
                  <div className="h-48 bg-gradient-to-br from-gray-200 to-gray-300 flex items-center justify-center">
                    <HomeIcon className="w-16 h-16 text-gray-400" />
                  </div>
                  <div className="p-6">
                    <h3 className="font-semibold text-lg text-gray-900 mb-2">
                      {project.title}
                    </h3>
                    <p className="text-sm text-gray-600 mb-4 line-clamp-2">
                      {project.story}
                    </p>
                    <div className="mb-4">
                      <div className="flex justify-between text-sm mb-2">
                        <span className="text-gray-600">Progress</span>
                        <span className="font-semibold text-gray-900">
                          ${project.currentAmount.toLocaleString()} / $
                          {project.targetAmount.toLocaleString()}
                        </span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div
                          className="bg-red-600 h-2 rounded-full transition-all"
                          style={{ width: `${Math.min(progress, 100)}%` }}
                        />
                      </div>
                    </div>
                    <div className="text-sm text-gray-500">
                      <span className="inline-block px-2 py-1 bg-gray-100 rounded">
                        {project.location}
                      </span>
                    </div>
                  </div>
                </Link>
              );
            })}
          </div>

          <div className="mt-8 text-center sm:hidden">
            <Link
              to="/projects"
              className="inline-flex items-center gap-2 text-red-600 font-semibold hover:text-red-700"
            >
              View All Projects
              <ArrowRight className="w-5 h-5" />
            </Link>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-red-600 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            Ready to Make a Difference?
          </h2>
          <p className="text-xl mb-8 text-red-100 max-w-2xl mx-auto">
            Your support can transform lives. Whether through donations or
            volunteering, every contribution matters.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              to="/donate"
              className="px-8 py-4 bg-white text-red-600 rounded-lg font-semibold hover:bg-red-50 transition-colors"
            >
              Donate Now
            </Link>
            <Link
              to="/volunteer"
              className="px-8 py-4 bg-red-700 text-white rounded-lg font-semibold hover:bg-red-800 transition-colors border-2 border-white"
            >
              Become a Volunteer
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
